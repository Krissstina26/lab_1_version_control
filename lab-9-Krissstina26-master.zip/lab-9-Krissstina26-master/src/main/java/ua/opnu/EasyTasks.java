package ua.opnu;

import java.util.List;
import java.util.stream.Collectors;

public class EasyTasks {

    public static void main(String[] args) {
        EasyTasks tasks = new EasyTasks();

        System.out.println("doubling([1, 2, 3]) -> " + tasks.doubling(List.of(1, 2, 3)));
        System.out.println("square([1, 2, 3]) -> " + tasks.square(List.of(1, 2, 3)));
        System.out.println("moreY([\"a\", \"b\", \"c\"]) -> " + tasks.moreY(List.of("a", "b", "c")));
        System.out.println("noNeg([1, -2, 3]) -> " + tasks.noNeg(List.of(1, -2, 3)));
        System.out.println("no9([1, 2, 19]) -> " + tasks.no9(List.of(1, 2, 19)));
        System.out.println("noZ([\"aaa\", \"bbb\", \"aza\"]) -> " + tasks.noZ(List.of("aaa", "bbb", "aza")));
        System.out.println("refinedStrings([\"aa\", \"c\", \"aa\", \"bbb\"]) -> " + tasks.refinedStrings(List.of("aa", "c", "aa", "bbb")));
        System.out.println("flatten([\"John Wick\", \"John Snow\", \"Alex Murphy\"]) -> " + tasks.flatten(List.of("John Wick", "John Snow", "Alex Murphy")));
    }

    // Завдання 1: Помноження на 2
    public List<Integer> doubling(List<Integer> nums) {
        return nums.stream()
                .map(n -> n * 2)
                .collect(Collectors.toList());
    }

    // Завдання 2: Піднесення до квадрату
    public List<Integer> square(List<Integer> nums) {
        return nums.stream()
                .map(n -> n * n)
                .collect(Collectors.toList());
    }

    // Завдання 3: Додавання 'y' на початку і в кінці
    public List<String> moreY(List<String> strings) {
        return strings.stream()
                .map(s -> "y" + s + "y")
                .collect(Collectors.toList());
    }

    // Завдання 4: Видалення негативних чисел
    public List<Integer> noNeg(List<Integer> nums) {
        return nums.stream()
                .filter(n -> n >= 0)
                .collect(Collectors.toList());
    }

    // Завдання 5: Видалення чисел, що закінчуються на 9
    public List<Integer> no9(List<Integer> nums) {
        return nums.stream()
                .filter(n -> n % 10 != 9)
                .collect(Collectors.toList());
    }

    // Завдання 6: Видалення рядків, що містять 'z'
    public List<String> noZ(List<String> strings) {
        return strings.stream()
                .filter(s -> !s.contains("z"))
                .collect(Collectors.toList());
    }

    // Завдання 7: Унікальні рядки, відсортовані за зменшенням довжини
    public List<String> refinedStrings(List<String> strings) {
        return strings.stream()
                .distinct()
                .sorted((s1, s2) -> Integer.compare(s2.length(), s1.length()))
                .collect(Collectors.toList());
    }

    // Завдання 8: Розбиття на окремі слова
    public List<String> flatten(List<String> strings) {
        return strings.stream()
                .flatMap(s -> List.of(s.split(" ")).stream())
                .collect(Collectors.toList());
    }
}