package ua.opnu;

import ua.opnu.util.Customer;
import ua.opnu.util.DataProvider;
import ua.opnu.util.Order;
import ua.opnu.util.Product;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class HardTasks {

    private final List<Customer> customers = DataProvider.customers;
    private final List<Order> orders = DataProvider.orders;
    private final List<Product> products = DataProvider.products;

    public static void main(String[] args) {
        HardTasks tasks = new HardTasks();

        // Для того, щоб побачити в консолі результат роботи методу, разкоментуйте відповідний рядок коду

        // Завдання 1
        Objects.requireNonNull(tasks.getBooksWithPrice(),"Method getBooksWithPrice() returns null").forEach(System.out::println);

        // Завдання 2
        Objects.requireNonNull(tasks.getOrdersWithBabyProducts(),"Method getOrdersWithBabyProducts() returns null").forEach(System.out::println);

        // Завдання 3
        Objects.requireNonNull(tasks.applyDiscountToToys(),"Method applyDiscountToToys() returns null").forEach(System.out::println);

        // Завдання 4
        System.out.println(Objects.requireNonNull(tasks.getCheapestBook(),"Method getCheapestBook() returns null").get());

        // Завдання 5
        Objects.requireNonNull(tasks.getRecentOrders(),"Method getRecentOrders() returns null").forEach(System.out::println);

        // Завдання 6
        DoubleSummaryStatistics statistics = Objects.requireNonNull(tasks.getBooksStats(), "Method getBooksStats() returns null");
        System.out.printf("count = %1$d, average = %2$f, max = %3$f, min = %4$f, sum = %5$f%n", statistics.getCount(), statistics.getAverage(), statistics.getMax(), statistics.getMin(), statistics.getSum());

        // Завдання 7
        Objects.requireNonNull(tasks.getOrdersProductsMap(),"Method getOrdersProductsMap() returns null").forEach((id, size) -> System.out.printf("%1$d : %2$d\n", id, size));

        // Завдання 8
        Objects.requireNonNull(tasks.getProductsByCategory(), "Method getProductsByCategory() returns null").forEach((name, list) -> System.out.printf("%1$s : %2$s\n", name, Arrays.toString(list.toArray())));
    }

    // Завдання 1: Повертає товари категорії Books з ціною більше 100
    public List<Product> getBooksWithPrice() {
        return products.stream()
                .filter(product -> "Books".equals(product.getCategory()) && product.getPrice() > 100)
                .collect(Collectors.toList());
    }

    // Завдання 2: Повертає замовлення, які містять товари категорії Baby
    public List<Order> getOrdersWithBabyProducts() {
        return orders.stream()
                .filter(order -> order.getProducts().stream().anyMatch(product -> "Baby".equals(product.getCategory())))
                .collect(Collectors.toList());
    }

    // Завдання 3: Застосовує знижку 50% до товарів категорії Toys
    public List<Product> applyDiscountToToys() {
        return products.stream()
                .filter(product -> "Toys".equals(product.getCategory()))
                .peek(product -> product.setPrice(product.getPrice() * 0.5))
                .collect(Collectors.toList());
    }

    // Завдання 4: Повертає найдешевший товар категорії Books
    public Optional<Product> getCheapestBook() {
        return products.stream()
                .filter(product -> "Books".equals(product.getCategory()))
                .min(Comparator.comparing(Product::getPrice));
    }

    // Завдання 5: Повертає три останні замовлення (найближчі до поточної дати)
    public List<Order> getRecentOrders() {
        return orders.stream()
                .sorted(Comparator.comparing(Order::getOrderDate).reversed())
                .limit(3)
                .collect(Collectors.toList());
    }

    // Завдання 6: Повертає статистику цін товарів категорії Books
    public DoubleSummaryStatistics getBooksStats() {
        return products.stream()
                .filter(product -> "Books".equals(product.getCategory()))
                .mapToDouble(Product::getPrice)
                .summaryStatistics();
    }

    // Завдання 7: Повертає відображення, де ключ — це id замовлення, а значення — кількість товарів у замовленні
    public Map<Integer, Integer> getOrdersProductsMap() {
        return orders.stream()
                .collect(Collectors.toMap(
                        Order::getId,
                        order -> order.getProducts().size()
                ));
    }

    // Завдання 8: Повертає товари, згруповані за категорією
    public Map<String, List<Integer>> getProductsByCategory() {
        return products.stream()
                // Групуємо  за категорією
                .collect(Collectors.groupingBy(
                        Product::getCategory, // категорія товару
                        Collectors.mapping(Product::getId, Collectors.toList()) // список id товарів у цій категорії
                ));
    }
}
